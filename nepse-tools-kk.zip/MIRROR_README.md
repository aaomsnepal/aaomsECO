# NEPSE open-source tools — backup mirror

Cloned and verified on **2026-09-07** from real, currently-active GitHub repositories,
for [[kkpramod.com.np]] / Price Action Classroom. Historical data dumps were removed —
this keeps only the actual source code, so future updates from the original authors
aren't needed for this backup to stay useful as a code reference.

## What's included (safe to freely reuse — MIT licensed)

| Folder | Original repo | Author | License |
|---|---|---|---|
| `ShareSansarScraper` | github.com/OmitNomis/ShareSansarScraper | Pranil Shrestha | MIT |
| `go-nepse` | github.com/VoidArchive/go-nepse | Anish Shrestha | MIT |
| `sharesansar_datascrape` | github.com/sbmagar13/sharesansar_datascrape | Sagar Budhathoki | MIT |

MIT license means: free to copy, modify, redistribute, and use commercially —
**as long as the original LICENSE file inside each folder stays with the code.**
Don't delete those files.

## Included but RESTRICTED — do not use commercially

| Folder | Original repo | Restriction |
|---|---|---|
| `NepseAPI-Unofficial` | github.com/surajrimal07/NepseAPI-Unofficial | Ships an MIT license file, but its own README explicitly and repeatedly states: **"Commercial use is strictly prohibited."** That stated restriction is the real rule — treat this as reference/backup only. Do not wire it into any part of kkpramod.com.np or aaomsDigital without the author's separate permission. |

## NOT included — no license exists, backed up differently

These three repos have **no license file at all**, meaning the author hasn't legally
granted permission to copy or redistribute their code — only to view it on GitHub.
The correct way to preserve a copy of these, if they're ever deleted, is GitHub's own
**Fork** button (one click, on the repo's page) — not a raw code dump like this one:

- **Nepse-All-Scraper** (your current live data source) — github.com/SamirWagle/Nepse-All-Scraper → Fork it here: https://github.com/SamirWagle/Nepse-All-Scraper/fork
- **nepalstock-api** — github.com/Prabesh01/nepalstock-api → Fork: https://github.com/Prabesh01/nepalstock-api/fork
- **nepstonks** — github.com/sarojbelbase/nepstonks → Fork: https://github.com/sarojbelbase/nepstonks/fork

Forking keeps GitHub's own permission and attribution intact, and if the original
is ever deleted, your fork keeps working exactly as before — no extra step needed
from you right now beyond clicking Fork once.

## Why this split

Not every open-source project can legally be copied and rehosted the same way.
This mirror only bundles what's actually safe to redistribute. Everything else
gets the right tool for the job (GitHub's own Fork) instead of a shortcut that
could put you in a bad spot later.
